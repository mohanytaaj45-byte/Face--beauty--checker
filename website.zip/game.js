const photoUpload = document.getElementById('photo-upload');
const preview = document.getElementById('preview');
const result = document.getElementById('result');
const analyzeBtn = document.getElementById('analyze-btn');

photoUpload.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.src = e.target.result;
            preview.style.display = 'block';
            result.style.display = 'none';
        };
        reader.readAsDataURL(file);
    }
});

analyzeBtn.addEventListener('click', analyzePhoto);

function analyzePhoto() {
    if (!preview.src) {
        alert('Please upload a photo first!');
        return;
    }

    const beautyScore = Math.floor(Math.random() * (90 - 60 + 1)) + 60;
    const flawPercentage = Math.floor(Math.random() * 20);
    result.innerHTML = `
        <p><strong>Beauty Score:</strong> ${beautyScore}%</p>
        <p><strong>Flaw Percentage:</strong> ${flawPercentage}%</p>
        <p><strong>Analysis:</strong> Your facial features show good symmetry and balance. 
        ${flawPercentage > 10 ? 'Consider minor adjustments for optimal aesthetics.' : 'Your features are well-proportioned!'}</p>
    `;
    result.style.display = 'block';
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && document.activeElement === photoUpload) {
        photoUpload.click();
    }
    if (event.key === 'Enter' && document.activeElement.id === 'analyze-btn') {
        analyzePhoto();
    }
});
